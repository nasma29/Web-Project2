const express = require('express');
const cors = require('cors');
const pool = require('./db');
const path = require("path");
const app = express();

app.use(cors());
app.use(express.json());

app.use("/images", express.static(path.join(__dirname, "images")));


app.get('/', (req, res) => res.json({ message: 'Server is running' }));


app.get('/menu', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM menuitems'); 
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log('Server listening on', PORT));




