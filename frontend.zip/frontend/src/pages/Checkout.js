import React, { useState } from 'react';
import logo from "../assets/logo.png"; 
import '../style/checkout.css';

function Checkout({ cart }) {
    const [isOrdered, setIsOrdered] = useState(false);
    const [customerInfo, setCustomerInfo] = useState({
        name: '',
        phone: '',
        address: '',
        branch: '' 
    });

    const cartItems = Array.isArray(cart) ? cart : [];

    const subtotal = cartItems.reduce((acc, item) => acc + (item.price * item.quantity), 0);
    const vat = subtotal * 0.11;
    const delivery = 1.00;
    const finalTotal = subtotal + vat + delivery;
    const totalProductCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

    const handlePlaceOrder = (e) => {
        e.preventDefault();
        if (!customerInfo.branch) {
            alert("Please select a branch!");
            return;
        }
        setIsOrdered(true);
    };

    return (
        <div className="checkout-page">
            <div className="overlay"></div>

            {!isOrdered ? (
                <div className="checkout-container">
                    <div className="info-form-card">
                        <h2 className="checkout-title">Complete Your Order</h2>
                        <form onSubmit={handlePlaceOrder}>
                            <div className="input-group">
                                <label>Branch Selection</label>
                                <select
                                    required
                                    value={customerInfo.branch}
                                    onChange={(e) =>
                                        setCustomerInfo({
                                            ...customerInfo,
                                            branch: e.target.value
                                        })
                                    }
                                >
                                    <option value="" disabled>
                                        -- Choose Branch --
                                    </option>
                                    <option value="Mkalles">Mkalles</option>
                                    <option value="Jal El Dib">Jal El Dib</option>
                                    <option value="Centro Mall">Centro Mall</option>
                                    <option value="Tayyoune">Tayyoune</option>
                                </select>
                            </div>
                            <div className="input-group">
                                <label>Name</label>
                                <input
                                    type="text"
                                    required
                                    onChange={(e) =>
                                        setCustomerInfo({
                                            ...customerInfo,
                                            name: e.target.value
                                        })
                                    }
                                />
                            </div>
                            <div className="input-group">
                                <label>Phone</label>
                                <input
                                    type="tel"
                                    required
                                    onChange={(e) =>
                                        setCustomerInfo({
                                            ...customerInfo,
                                            phone: e.target.value
                                        })
                                    }
                                />
                            </div>
                            <div className="input-group">
                                <label>Address</label>
                                <textarea
                                    required
                                    onChange={(e) =>
                                        setCustomerInfo({
                                            ...customerInfo,
                                            address: e.target.value
                                        })
                                    }
                                />
                            </div>
                            <button type="submit" className="place-order-btn">
                                Generate Receipt
                            </button>
                        </form>
                    </div>
                </div>
            ) : (
                <div className="receipt-overlay">
                    <div className="receipt-paper">
                        <img
                            src={logo}
                            alt="Snack Attack"
                            className="receipt-logo-bw"
                        />
                        <div className="receipt-branch-tag">
                            ORDER SERVED BY: {customerInfo.branch.toUpperCase()}
                        </div>
                        <div className="receipt-details">
                            <p>
                                <strong>Customer:</strong> {customerInfo.name}
                            </p>
                            <p>
                                <strong>Phone:</strong> {customerInfo.phone}
                            </p>
                        </div>
                        <div className="receipt-divider">
                            ------------------------------------------
                        </div>
                        <div className="receipt-items">
                            {cartItems.map((item, i) => (
                                <div key={i} className="receipt-item-row">
                                    <span>
                                        {item.quantity}x {item.name}
                                    </span>
                                    <span>
                                        $
                                        {(item.quantity * item.price).toFixed(
                                            2
                                        )}
                                    </span>
                                </div>
                            ))}
                        </div>
                        <div className="receipt-divider">
                            ------------------------------------------
                        </div>
                        <div className="receipt-summary">
                            <p>Subtotal: ${subtotal.toFixed(2)}</p>
                            <p>VAT (11%): ${vat.toFixed(2)}</p>
                            <p>Delivery: $1.00</p>
                            <p className="final-total">
                                TOTAL: ${finalTotal.toFixed(2)}
                            </p>
                        </div>
                        <div className="product-count-box">
                            TOTAL PRODUCTS: {totalProductCount}
                        </div>
                        <button
                            className="back-btn"
                            onClick={() => (window.location.href = '/')}
                        >
                            New Order
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
}

export default Checkout;
